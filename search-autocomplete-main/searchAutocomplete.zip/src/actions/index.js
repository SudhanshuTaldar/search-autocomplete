export const add = (data) => {
    return {
        type: "ADD_DATA",
        payload: {
            data: data
        }
    }
}
